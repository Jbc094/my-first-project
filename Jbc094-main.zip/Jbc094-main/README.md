# About me


**Jbc094/Jbc094** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on getting a new career.
- 🌱 I’m currently learning how to roll with the punches of life.
- 👯 I’m looking to collaborate on a luxury picnic gathering with friends. 💕
- 🤔 I’m looking for help with getting into Tech.
- 💬 Ask me about traveling, I'm your girl! ✈
- 😄 Pronouns: She/Her 
- ⚡ Fun fact: I've been in a coal mine. 💎

