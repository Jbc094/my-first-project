# Hello-World
The repository is for training with GitHub.
My name is Jade originally from Cincinnati, OH. I love to travel, eat good foods and enjoy a fun link up with family and friends!
